package com.example.uts;

public interface OnItemClickCallBack {
    void onItemClicked(Makanan makanan);
}
