package com.example.uts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.content.Intent;
import android.widget.Toast;
import java.util.ArrayList;
public class MainActivity extends AppCompatActivity {
    private RecyclerView Makanan;
    private ArrayList<Makanan> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Makanan = findViewById(R.id.makanan);
        Makanan.setHasFixedSize(true);

        list.addAll(MakananData.getListData());
        showRecyclerList();
    }

    private void showRecyclerList(){
        Makanan.setLayoutManager(new LinearLayoutManager(this));
        Adapter listMakananAdapter = new Adapter(list);
        Makanan.setAdapter(listMakananAdapter);

        listMakananAdapter.setOnItemClickCallback(new Adapter.OnItemClickCallback(){
            @Override
            public void onItemClicked(Makanan makanan){
                Intent moveIntent = new Intent(MainActivity.this, DetailMakananActivity.class);
                moveIntent.putExtra(DetailMakananActivity.ITEM_EXTRA, makanan);
                startActivity(moveIntent);
            }
        });
    }
}