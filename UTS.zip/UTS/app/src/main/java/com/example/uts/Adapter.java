package com.example.uts;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.ListViewHolder> {
    private ArrayList<Makanan> listMakanan;

    private OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback){
        this.onItemClickCallback = onItemClickCallback;
    }

    public Adapter(ArrayList<Makanan> list){
        this.listMakanan = list;
    }

    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_makanan, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        Makanan makanan = listMakanan.get(position);
        holder.Photo.setImageResource(makanan.getPhoto());
        holder.Name.setText(makanan.getNama());
        holder.Detail.setText(makanan.getHarga());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickCallback.onItemClicked(listMakanan.get(holder.getAdapterPosition()));
            }
        });

    }

    @Override
    public int getItemCount() {
        return listMakanan.size();
    }


    public class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView Photo;
        TextView Name;
        TextView Detail;
        ListViewHolder(View itemview) {
            super(itemview);
            Photo = itemview.findViewById(R.id.item_makanan);
            Name = itemview.findViewById(R.id.item_name);
            Detail = itemview.findViewById(R.id.detail);
        }
    }
    public interface OnItemClickCallback {
        void onItemClicked(Makanan data);
    }
}
