package com.example.uts;

import java.util.ArrayList;

public class MakananData {
    private static String[] NamaMakanan = {
            "Geprek",
            "Bakso",
            "Nasi Goreng",

    };

    private static String[] DetailMakanan = {
            "Ayam Geprek Sedap",
            "Bakso Setan",
            "Nasi Goreng Sedap",

    };

    private static String[] HargaMakanan = {
            "10.000",
            "10.000",
            "10.000",
    };

    private static int[] GambarMakanan = {
            R.drawable.geprek,
            R.drawable.bakso,
            R.drawable.nasgor,
    };

    static ArrayList<Makanan> getListData(){
        ArrayList<Makanan> list = new ArrayList<>();
        for (int position = 0; position <NamaMakanan.length; position++){
            Makanan makanan = new Makanan();
            makanan.setNama(NamaMakanan[position]);
            makanan.setDetail(DetailMakanan[position]);
            makanan.setHarga(HargaMakanan[position]);
            makanan.setPhoto(GambarMakanan[position]);
            list.add(makanan);
        }
        return list;
    }
}
