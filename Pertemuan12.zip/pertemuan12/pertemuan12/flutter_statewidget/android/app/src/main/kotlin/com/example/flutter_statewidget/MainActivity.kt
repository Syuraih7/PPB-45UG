package com.example.flutter_statewidget

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
