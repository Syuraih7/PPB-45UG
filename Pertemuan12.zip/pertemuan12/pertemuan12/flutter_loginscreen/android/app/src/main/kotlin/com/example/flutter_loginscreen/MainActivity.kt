package com.example.flutter_loginscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
